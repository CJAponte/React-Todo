import React from 'react';
import './Todo.css';

class ToDo extends React.Component{
    render(){
        return (
            <div>
                <div className="todoItem">
                    <p><strong>To Do :</strong></p><p>{this.props.todoProps.todoItem}</p>
                </div>
            </div>
        )
    }
}

export default ToDo